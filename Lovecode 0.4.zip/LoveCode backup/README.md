# LoveCode
An implementation of Makecode Arcade in LÖVE

This is a BIG work in progress!

there is some example code in the `code.lua` file, if you you can delete the code but NOT the functions, or else it will not work!

to run the code, you will need a love executable (you can download one from https://love2d.org/)
then you can simply drag the folder into the executable and the code will run!
